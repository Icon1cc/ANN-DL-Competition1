import os
import numpy as np
import tensorflow as tf

num_categories = 6
seq_length_LSTM = 128        # predictions based on previous seq_length data entries
forecast_length = 9     # predicting forecast_length time steps into the future (9 for Phase 1, 18 for Phase 2)
seq_length_GRU = 26         # predictions based on previous seq_length data entries
sample_length_GRU = seq_length_GRU + forecast_length
sample_length_LSTM = seq_length_LSTM + forecast_length
    
class model:
    def __init__(self, path):
        self.model = (tf.keras.models.load_model(os.path.join(path, 'LSTMModel')), tf.keras.models.load_model(os.path.join(path, 'GRUModel')))

    def predict(self, X, features):
        X_LSTM = X[:, -seq_length_LSTM:]
        X_GRU = X[:, -seq_length_GRU:]
        out = self.model[0].predict(X_LSTM)+self.model[1].predict(X_GRU)  # shape forecast_length
        return out/2

