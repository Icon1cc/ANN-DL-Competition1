import os
import joblib
import numpy as np
import tensorflow as tf

seq_length = 128            # predictions based on previous seq_length data entries
forecast_length = 18        # predicting forecast_length time steps into the future
model_output_length = 9     # amount of samples predicted by model.predict(X)

class model:
    def __init__(self, path):
        self.rscaler_X = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_X.save'))
        self.rscaler_y = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_y.save'))

        self.models = {}
        models_path = os.path.join(path, 'SubmissionModel/models')
        for model in os.listdir(models_path):
            self.models[model] = tf.keras.models.load_model(os.path.join(models_path, model))


    def predict(self, X, categories):

        X = X[:, -seq_length:]
        X = self.rscaler_X.transform(X)

        out = []
        for i, time_series in enumerate(X):
            category = categories[i]                                    

            # Predict samples 1-9
            y_pred_9first = self.models[category].predict(tf.reshape(time_series, (1, seq_length, 1)))  

            # Extend input time series with predicted values
            time_series = np.concatenate((time_series[model_output_length:], tf.reshape(y_pred_9first, (-1))), axis=0)

            # Predict samples 10-18
            y_pred_9last = self.models[category].predict(tf.reshape(time_series, (1, seq_length, 1)))  

            # Inverse transform predictions to original dimension and concatenate
            y_pred_9first_iscaled = self.rscaler_y.inverse_transform(tf.reshape(y_pred_9first, (1, model_output_length)))
            y_pred_9last_iscaled = self.rscaler_y.inverse_transform(tf.reshape(y_pred_9last, (1, model_output_length)))
            predictions_iscaled = np.concatenate((tf.reshape(y_pred_9first_iscaled, (-1)), tf.reshape(y_pred_9last_iscaled, (-1))), axis=0)

            out.append(predictions_iscaled)

        out = np.array(out)
        return out