import os
import numpy as np
import tensorflow as tf

num_categories = 6
seq_length = 26         # predictions based on previous seq_length data entries
forecast_length = 9     # predicting forecast_length time steps into the future (9 for Phase 1, 18 for Phase 2)
sample_length = seq_length + forecast_length

v_category_to_float = np.vectorize(lambda char: ord(char) / ord('A'))

class model:
    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel'))

    def predict(self, X, categories):

        X = X[:, -seq_length:]
        categories = v_category_to_float(categories)
        
        input = []
        for i, x in enumerate(X):
            time_column = x
            category_column = np.full_like(x, fill_value=categories[i])
            input.append(np.column_stack((time_column, category_column)))

        input = np.array(input)
        out = self.model.predict(input)  # shape forecast_length
        return out
