import os
import joblib
import numpy as np
import tensorflow as tf

seq_length = 128        # predictions based on previous seq_length data entries
forecast_length = 18    # predicting forecast_length time steps into the future

class model:
    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel/model'))
        self.rscaler_X = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_X.save'))
        self.rscaler_y = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_y.save'))

    def predict(self, X, categories):

        X = X[:, -seq_length:]
        X = self.rscaler_X.transform(X)

        y_pred = self.model.predict(X) 
        out = self.rscaler_y.inverse_transform(y_pred.reshape((-1, forecast_length)))
        return out
 