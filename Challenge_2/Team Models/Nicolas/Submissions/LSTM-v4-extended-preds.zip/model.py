import os
import joblib
import numpy as np
import tensorflow as tf

seq_length = 128            # predictions based on previous seq_length data entries
forecast_length = 18        # predicting forecast_length time steps into the future
model_output_length = 9     # amount of samples predicted by model.predict(X)

class model:
    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel/model'))
        self.rscaler_X = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_X.save'))
        self.rscaler_y = joblib.load(os.path.join(path, 'SubmissionModel/rscaler_y.save'))

    def predict(self, X, categories):

        X = X[:, -seq_length:]
        X = self.rscaler_X.transform(X)

        # Predict samples 1-9
        y_pred_9first = self.model.predict(X)

        # Extend X_val with predicted values
        for i, sample in enumerate(X):
            X[i] = np.concatenate((sample[model_output_length:], y_pred_9first[i]), axis=0)

        # Predict samples 10-18
        y_pred_9last = self.model.predict(X)

        # Inverse transform predictions to original dimension and concatenate
        y_pred_9first_iscaled = self.rscaler_y.inverse_transform(y_pred_9first.reshape((-1, model_output_length)))
        y_pred_9last_iscaled = self.rscaler_y.inverse_transform(y_pred_9last.reshape((-1, model_output_length)))
        out = np.concatenate((y_pred_9first_iscaled, y_pred_9last_iscaled), axis=1)

        return out