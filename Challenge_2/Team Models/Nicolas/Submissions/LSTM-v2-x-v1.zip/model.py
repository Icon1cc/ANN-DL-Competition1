import os
import numpy as np
import tensorflow as tf

seq_length = 128        # predictions based on previous seq_length data entries

class model:
    def __init__(self, path):
        self.models = {}
        models_path = os.path.join(path, 'SubmissionModel')
        for model in os.listdir(models_path):
            self.models[model] = tf.keras.models.load_model(os.path.join(models_path, model))

    def predict(self, X, categories):
        X = X[:, -seq_length:]

        out = []
        for i, time_series in enumerate(X):
            category = categories[i]
            time_series = tf.reshape(time_series, (1, seq_length, 1))   # expected dimension of predict function
            predictions = self.models[category].predict(time_series)    # predict with model corresponding to category
            predictions = tf.reshape(predictions, (-1))                 # convert predictions to shape (forecast_length,)
            out.append(predictions)

        out = np.array(out)
        return out